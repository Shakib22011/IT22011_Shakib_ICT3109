package com.exception;

public class InvalidDeptException extends Exception {
    public InvalidDeptException(String message) {
        super(message);
    }
}
