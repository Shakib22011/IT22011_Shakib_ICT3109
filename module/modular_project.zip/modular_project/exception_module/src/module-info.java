module exception.module {
    exports com.exception;
}