module main.portion {
    requires exception_module;
}