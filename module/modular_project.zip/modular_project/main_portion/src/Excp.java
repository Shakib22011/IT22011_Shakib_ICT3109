import java.util.Scanner;
public class Excp {
    public static void validateAge(int age,String dept) throws InvalidAgeException,InvalidDeptException{
        if (age < 18) {
            throw new InvalidAgeException("Age must be 18 or above.");
        }
        if(!dept.equals("ICT")){
            throw new InvalidDeptException("Invalid dept");
        }
        System.out.println("Valid age: " + age);
        System.out.println("Valid dept: " + dept);
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter an age: ");
        int age=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter an dept: ");
        String dept=sc.nextLine();
        try {
            validateAge(age,dept);
        } catch (InvalidAgeException e) {
            System.out.println("Caught Age Exception: " + e.getMessage());
        } catch (InvalidDeptException e) {
            System.out.println("Caught Dept Exception: " + e.getMessage());
        }
    }

}
